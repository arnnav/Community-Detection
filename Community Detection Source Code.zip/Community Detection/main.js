var json = require('./actors.json');  
    var config = {
      dataSource: json,
	   rootNodeRadius: 30,
	    cluster: true,

  showControlDash: true,

  showStats: true,
  nodeStats: true,

  showFilters: true,
  nodeFilters: true,
nodeCaption: 'name', 
        	nodeMouseOver: 'name',
  captionToggle: true,
  edgesToggle: true,
  nodesToggle: true,
  toggleRootNotes: false,

  zoomControls: true,
  clusterColours: ["#1B9E77","#D95F02","#7570B3","#E7298A","#66A61E","#E6AB02"]
    };
    
    alchemy = new Alchemy(config);