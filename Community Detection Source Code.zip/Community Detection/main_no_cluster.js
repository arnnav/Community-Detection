var json = require('./actors.json');  
    var config = {
      dataSource: json,
	   
	nodeCaption: 'name', 
    nodeMouseOver: 'name',
  
    };
    
    alchemy = new Alchemy(config);